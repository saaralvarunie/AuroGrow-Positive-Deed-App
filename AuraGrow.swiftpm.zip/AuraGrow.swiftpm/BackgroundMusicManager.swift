@preconcurrency import AVFoundation

@MainActor
class BackgroundMusicManager {
    static let shared = BackgroundMusicManager()
    private var audioPlayer: AVAudioPlayer?

    // 🎵 Available Music Tracks
    private let musicFiles: [String: String] = [
        "Relaxing": "relaxing_music",
        "Happy": "happy_music",
        "Focus": "focus_music"
    ]

    private init() {}

    // 🎧 Play Selected Music
    func setMusic(trackName: String) {
        stopMusic()  // Stop any currently playing music
        
        guard let fileName = musicFiles[trackName],
              let url = Bundle.main.url(forResource: fileName, withExtension: "mp3") else {
            print("⚠️ Music file not found: \(trackName)")
            return
        }

        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.numberOfLoops = -1
            audioPlayer?.volume = 0.5  // Default volume level
            audioPlayer?.prepareToPlay()
            audioPlayer?.play()
            print("✅ Now playing: \(trackName)")
        } catch {
            print("🚨 Error playing music: \(error.localizedDescription)")
        }
    }

    // ⏹️ Stop Music (with Fade Out)
    func stopMusic() {
        guard let player = audioPlayer else { return }

        DispatchQueue.global(qos: .userInitiated).async {
            while player.volume > 0 {
                player.volume -= 0.1
                usleep(200_000) // 0.2 seconds delay
            }
            player.stop()
            DispatchQueue.main.async {
                self.audioPlayer = nil
                print("⏹️ Music stopped")
            }
        }
    }
}
