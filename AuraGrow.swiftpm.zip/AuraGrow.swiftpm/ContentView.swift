import SwiftUI

struct ContentView: View {
    @AppStorage("hasCompletedOnboarding") private var hasCompletedOnboarding: Bool = false
    @AppStorage("petName") private var petName: String = "" // Store pet name
    @State private var showTabView = false

    var body: some View {
        if !hasCompletedOnboarding {
            // 🚀 First-time onboarding
            OnboardingView()
        } else if !showTabView {
            // 🌟 Show greeting for a few seconds
            VStack {
                Text("Welcome back, \(petName)! 🎉")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .transition(.opacity)
            }
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                    showTabView = true
                }
            }
        } else {
            // 🏠 Main app content (TabView)
            TabView {
                HomeView()
                    .tabItem {
                        Label("Home", systemImage: "house.fill")
                    }

                ProfileView()
                    .tabItem {
                        Label("Profile", systemImage: "person.fill")
                    }

                SettingsView()
                    .tabItem {
                        Label("Settings", systemImage: "gearshape.fill")
                    }
            }
        }
    }
}

// 🔍 Preview
#Preview {
    ContentView()
}
