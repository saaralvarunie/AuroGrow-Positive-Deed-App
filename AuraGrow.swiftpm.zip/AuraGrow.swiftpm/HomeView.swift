import SwiftUI
import AVFoundation

struct HomeView: View {
    @AppStorage("streak") private var streak: Int = 0
    @AppStorage("petStage") private var petStage: Int = 0
    @AppStorage("petType") private var petType: String = "Parrot"
    @AppStorage("completedPets") private var completedPets: String = ""
    @AppStorage("petName") private var petName: String = "Chirpy 🐦"
    @AppStorage("tasksCompleted") private var tasksCompleted: Int = 0
    @AppStorage("badgeCount") private var badgeCount: Int = 0
    
    @State private var dailyDeed: String = "Compliment someone today!"
    @State private var isCompleted: Bool = false
    @State private var showDescription: Bool = false
    @State private var showBadgePopup = false
    @State private var showProgressPopup = false
    @State private var showMotivationPopup = false
    
    let deeds = [
        "Smile at a stranger 😊",
        "Help someone in need 🤝",
        "Say something kind 💬",
        "Donate an old item 🎁",
        "Write a positive note 📝",
        "Compliment someone sincerely 🌟",
        "Hold the door open 🚪",
        "Let someone go ahead in line 🛒",
        "Pick up litter and dispose of it properly 🗑️",
        "Send a thank-you message 📩",
        "Call a friend just to check in ☎️",
        "Water a plant or tree 🌱",
        "Leave a kind comment online 💻",
        "Offer your seat to someone in need 🚋",
        "Share your food with someone 🍎",
        "Support a local business 🏪",
        "Leave an uplifting sticky note 🗒️",
        "Help a family member with a chore 🧹",
        "Donate books to a library 📚",
        "Make someone laugh 😂",
        "Encourage someone’s dreams ✨",
        "Say 'thank you' to a worker 👏",
        "Give a genuine apology when needed 🙏",
        "Spend time with a lonely person 🕰️",
        "Return a misplaced item 🔄",
        "Write a kind letter to yourself ✍️",
        "Share an inspiring story 📖",
        "Support someone’s creative work 🎨",
        "Help a lost person with directions 🗺️",
        "Bake or cook for someone 🍪",
        "Say 'good morning' to a stranger ☀️",
        "Leave a bigger tip than usual 💰",
        "Check in on an elderly neighbor 👵",
        "Be patient in a long queue 🕰️",
        "Buy a small gift for someone 🎀",
        "Give a warm hug to a loved one 🤗",
        "Send a random compliment text 📱",
        "Share knowledge with someone who needs it 🧠",
        "Teach someone a new skill 🎓",
        "Write a gratitude list 📜",
        "Tell someone why they are special 💖",
        "Put your phone away during a conversation 📵",
        "Help an animal in need 🐾",
        "Give away an extra umbrella on a rainy day ☔",
        "Tell a joke to make someone smile 🤡",
        "Encourage someone who’s struggling 💪",
        "Say 'please' and 'thank you' often 🙌",
        "Give someone a small handmade gift 🎁",
        "Pay for someone’s coffee or meal ☕",
        "Forgive someone (even if they don’t ask) 💕",
        "Surprise someone with a handwritten letter ✉️",
        "Share your umbrella with someone ☂️",
        "Let a car merge in front of you 🚗",
        "Hold the elevator for someone 🏢",
        "Write a nice review for a business 📝",
        "Help a coworker with a task 🤝",
        "Tell someone they did a great job 🌟",
        "Encourage someone to take a break 🍵",
        "Help carry someone’s heavy bags 🎒",
        "Be kind to yourself today 💙",
        "Turn off unnecessary lights to save energy 💡",
        "Give someone your full attention 👂",
        "Offer a ride to someone in need 🚘",
        "Write a motivational quote for someone 🖊️",
        "Help a child with their homework 📚",
        "Return your shopping cart to the right place 🛒",
        "Bring snacks to share with others 🍩",
        "Donate warm clothes to a shelter 🧥",
        "Check in with a friend going through a tough time 💌",
        "Support someone’s small business 🛍️",
        "Encourage a child’s creativity 🎭",
        "Be extra patient with customer service workers 📞",
        "Wave or say 'hi' to a neighbor 👋",
        "Make a playlist for someone who needs cheering up 🎶",
        "Help a tourist or visitor feel welcome 🌎",
        "Write a positive review for a friend’s work ✏️",
        "Spend time playing with a pet 🐶",
        "Give someone an unexpected 'just because' gift 🎉",
        "Offer water to a delivery driver or worker 🚚",
        "Remind someone of their strengths 💪",
        "Say something nice about yourself in the mirror 🪞",
        "Pick up and return something someone dropped 🔄",
        "Encourage kids to be kind 💕",
        "Teach someone a phrase in a different language 🌍",
        "Smile at yourself in the mirror today 😊",
        "Plant a tree or flower 🌳",
        "Help someone cross the street safely 🚶‍♂️",
        "Listen without interrupting during a conversation 🗣️",
        "Leave a positive sticky note in a public place 📝",
        "Share an extra coupon or discount with someone 🏷️",
        "Write a list of things you love about a friend 💗",
        "Give away extra food to someone in need 🍽️",
        "Send a postcard to a long-distance friend 📬",
        "Make a DIY gift and surprise someone 🎨",
        "Start a conversation with someone who seems lonely 💬",
        "Give a shout-out to someone doing great work 📢",
        "Make a care package for someone in need 🎁",
        "Stay calm and kind in a frustrating situation ☮️",
        "Encourage someone to follow their passion 🌠",
        "Take a moment to appreciate nature 🍃",
        "Help an overwhelmed friend organize something 📦",
        "Say something nice about someone behind their back 💬",
        "Help a teacher, nurse, or frontline worker 💉",
        "Compliment someone’s effort, not just results 🏆",
        "Donate unused blankets or towels to an animal shelter 🛏️"
    ];
    
    
    let deedDescriptions: [String: String] = [
        "Smile at a stranger 😊": "A simple smile can brighten someone's day!",
        "Help someone in need 🤝": "Even a small act of kindness goes a long way.",
        "Say something kind 💬": "A kind word can uplift someone's mood instantly.",
        "Donate an old item 🎁": "Give away something you don’t need to someone who does.",
        "Write a positive note 📝": "Leave an encouraging note for someone to find!",
        "Compliment someone sincerely 🌟": "A genuine compliment can make someone's day!",
        "Hold the door open 🚪": "A small gesture that shows big kindness.",
        "Let someone go ahead in line 🛒": "A simple way to show patience and generosity.",
        "Pick up litter and dispose of it properly 🗑️": "Keep the environment clean and beautiful!",
        "Send a thank-you message 📩": "Express gratitude to someone who has helped you.",
        "Call a friend just to check in ☎️": "A quick chat can make someone feel cared for.",
        "Water a plant or tree 🌱": "Nurture nature and help the environment thrive!",
        "Leave a kind comment online 💻": "Spread positivity on social media or forums.",
        "Offer your seat to someone in need 🚋": "Give up your seat to someone who needs it more.",
        "Share your food with someone 🍎": "A small act of sharing can mean a lot to someone.",
        "Support a local business 🏪": "Help your community grow by shopping locally!",
        "Leave an uplifting sticky note 🗒️": "Surprise someone with an unexpected positive message.",
        "Help a family member with a chore 🧹": "Lighten someone’s load by lending a hand.",
        "Donate books to a library 📚": "Give the gift of knowledge and stories!",
        "Make someone laugh 😂": "Laughter is the best medicine—spread the joy!",
        "Give someone a genuine hug 🤗": "A hug can bring warmth and comfort.",
        "Write a letter to your future self ✉️": "Reflect and send yourself some encouragement!",
        "Pay for someone’s coffee ☕": "A small surprise that can make someone's day.",
        "Plant a tree 🌳": "A gift for the future and the environment!",
        "Encourage a struggling friend 💖": "Your words can inspire and uplift someone.",
        "Volunteer for a cause 🏡": "Help others and create a positive impact.",
        "Make a handmade gift 🎨": "A personal touch makes a gift more meaningful.",
        "Leave an extra tip at a restaurant 💵": "Show appreciation to those who serve.",
        "Write down three things you're grateful for ✨": "Gratitude brings more joy into your life!",
        "Say 'thank you' and mean it 🙏": "A simple but powerful way to show appreciation.",
        "Give someone a heartfelt handwritten note ✍️": "Writing by hand adds a personal touch.",
        "Send a postcard to a friend 📬": "A surprise in the mail can make anyone smile!",
        "Babysit for free for a friend 👶": "Help someone take a well-deserved break.",
        "Buy groceries for someone in need 🛍️": "Food is love—share it when you can.",
        "Tell a joke to cheer someone up 🤣": "Laughter spreads happiness!",
        "Help someone carry their groceries 🛒": "Small efforts can mean a lot.",
        "Encourage a beginner 🎸": "We all start somewhere—your words matter!",
        "Donate pet food to an animal shelter 🐶": "Help furry friends in need!",
        "Recycle properly ♻️": "Take care of the planet, one step at a time.",
        "Be patient in traffic 🚗": "Patience makes the road a better place.",
        "Write a thank-you note to a teacher ✏️": "Teachers shape lives—show them appreciation!",
        "Offer to help an elderly neighbor 👵": "A small act of kindness goes a long way.",
        "Bring treats to work or school 🍪": "Sweeten everyone's day with a surprise!",
        "Call your parents just to say hi 📞": "They’ll love hearing from you!",
        "Forgive someone (even if they didn’t apologize) 💙": "Letting go lightens your heart.",
        "Let someone merge in traffic 🚦": "A kind gesture can ease someone’s commute.",
        "Donate warm clothes to those in need 🧥": "Help someone stay warm during cold days.",
        "Help a lost person find their way 🗺️": "A moment of kindness can mean everything.",
        "Smile while answering the phone 📱": "Your voice sounds warmer when you smile!",
        "Buy a small gift for a coworker 🎁": "Surprise someone with an unexpected act of kindness.",
        "Write a review for a business you love 📝": "Support small businesses with kind words.",
        "Encourage someone’s dreams ✨": "Your support can be life-changing!",
        "Take time to listen to someone 👂": "Sometimes, people just need to be heard.",
        "Adopt a ‘no complaints’ day 🚫": "Focus on the positive for a day!",
        "Leave a kind message on a random car 🚗": "A fun way to brighten someone's day!",
        "Buy a book for a child 📖": "Inspire a love for reading!",
        "Hold back from interrupting during a conversation 🤐": "Let people finish their thoughts!",
        "Organize a community clean-up 🌎": "Make your surroundings better for everyone.",
        "Give a genuine thumbs-up 👍": "A simple but encouraging gesture.",
        "Tell someone you appreciate them 💕": "Make sure people know they matter!",
        "Laugh at someone’s bad joke 😂": "Let them enjoy the moment.",
        "Let someone borrow something you value 🔑": "Sharing builds trust!",
        "Give someone your full attention 👀": "Put your phone down and truly listen.",
        "Buy a meal for a homeless person 🍛": "Share a meal and kindness.",
        "Return your shopping cart 🛒": "A small act that helps store employees.",
        "Help someone learn something new 📚": "Share your knowledge generously!",
        "Leave a little extra in a tip jar 💰": "Baristas and cashiers will appreciate it!",
        "Write a kind note on a restaurant receipt 📝": "Brighten a server’s day!",
        "Say hello to a lonely neighbor 👋": "A small greeting can mean so much.",
        "Take a moment to appreciate nature 🌄": "Mindfulness brings peace and gratitude.",
        "Let someone have the last piece of food 🍰": "Selflessness in action!",
        "Send a care package 📦": "A thoughtful package can make someone’s day.",
        "Buy a treat for your pet 🐾": "Pets deserve kindness too!",
        "Make someone’s favorite meal 🍲": "Food made with love tastes even better.",
        "Write a song or poem for a friend 🎶": "A creative way to show appreciation!",
        "Send flowers to someone just because 🌸": "Unexpected flowers bring joy!",
        "Give a social media shoutout 📢": "Publicly appreciate someone’s kindness!",
        "Let someone else have the good seat 🎭": "Small sacrifices make big smiles.",
        "Celebrate someone’s small victory 🎉": "Every success deserves recognition!",
        "Encourage someone facing a challenge 💪": "Support goes a long way!",
        "Be extra polite for a day 🏆": "Small manners make big differences!",
        "Write down why you’re proud of yourself 🏅": "Self-love is just as important!",
        "Help someone brainstorm ideas 🧠": "Collaboration leads to great things!",
        "Pass on a good book to someone 📖": "Stories are best when shared!",
        "Be the reason someone smiles today 😊": "Your kindness can change someone's day!"
    ]
    
    
    let motivationalMessages = [
        "Keep going, you're doing great! 🌟",
        "Your kindness makes the world brighter! 💖",
        "Every deed counts! Keep up the good work! 🎉",
        "You're spreading positivity! Keep it up! ✨",
        "One act of kindness at a time! 💪",
        "Small deeds, big impact! Keep shining! ☀️",
        "You're making the world a better place! 🌍",
        "Kindness is your superpower! 🦸‍♂️",
        "Good vibes only! You're awesome! 😎",
        "Every little act of kindness matters! ❤️",
        "Keep lifting others up! You're amazing! 🚀",
        "Your good deeds create ripples of joy! 🌊",
        "The world needs more people like you! 🌟",
        "You're growing kindness like a garden! 🌱",
        "Your heart is as big as the sky! ☁️",
        "Stay positive, keep spreading joy! 😃",
        "Your kindness inspires others! Keep going! 💫",
        "You're a kindness champion! 🏆",
        "Acts of kindness are acts of greatness! 💎",
        "Happiness grows when shared! 🌻",
        "You're doing better than you think! 💙",
        "You make someone's day every day! ☀️",
        "Kindness is the language of the heart! 💓",
        "Your light shines bright! Keep glowing! ✨",
        "You're unstoppable in spreading joy! 🎊",
        "One good deed at a time, you're changing the world! 🌍",
        "Be proud of yourself! You're amazing! 🎖️",
        "Kind hearts like yours make the world beautiful! 🌹",
        "You're making kindness cool! 😎",
        "Keep believing in the power of good! 💕",
        "Even small deeds create big smiles! 😊",
        "You're a hero of kindness! 🦸‍♀️",
        "Your positive energy is contagious! 🌈",
        "Helping others is your super skill! ⚡",
        "Kindness grows just like your pet! 🐥",
        "The kindness you give comes back to you! 🔄",
        "You're a bright light in the world! 💡",
        "Every time you help, you make a difference! 🌟",
        "Your heart is full of magic! ✨",
        "Your kindness journey is inspiring! 🚀",
        "Love and kindness are your strengths! ❤️",
        "You're creating happiness wherever you go! 🎈",
        "You're turning small moments into big joy! 🎊",
        "The world smiles because of you! 😊",
        "Kindness is your daily superpower! 🦸",
        "Your kindness helps everyone grow! 🌿",
        "Be proud of the goodness you're spreading! 🏅",
        "You are a kindness legend in the making! 🏆",
        "Every kind act makes the world better! 🌍",
        "You're making kindness a habit! 💖",
        "Your kindness journey is truly inspiring! ✨"
    ]
    
    
    let maxPetStage = 5
    let birdOptions = ["Parrot", "Canary", "Sparrow", "Owl", "Pigeon", "Peacock"]
    
    var petImage: String {
        return "\(petType.lowercased())\(min(petStage + 1, maxPetStage))"
    }
    
    var body: some View {
        VStack(spacing: 20) {
            Spacer()
            
            Text("Your, \(petName) is Growing!")
                .font(.title)
                .fontWeight(.bold)
            
            Image(petImage)
                .resizable()
                .frame(width: 150, height: 150)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.blue, lineWidth: 4))
                .padding(.bottom, 5)
                .animation(.spring(), value: petStage)
            
            Text(petName)
                .font(.headline)
                .padding(8)
                .background(Color.blue.opacity(0.2))
                .cornerRadius(10)
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.blue, lineWidth: 2))
            
            // 🔥 Streak Counter
            Text("🔥 Streak: \(streak)")
                .font(.headline)
            
            
            // 📜 Task Section
            VStack {
                Text("Positive Deed:")
                    .font(.headline)
                    .padding(.top)
                
                Text("💬 \(dailyDeed)")
                    .font(.body)
                    .multilineTextAlignment(.center)
                    .padding()
                    .background(Color.yellow.opacity(0.2))
                    .cornerRadius(10)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.yellow, lineWidth: 2)
                    )
                    .onTapGesture {
                        showDescription.toggle()
                    }
                
                if showDescription {
                    Text(deedDescriptions[dailyDeed] ?? "Completing this will help your pet grow! 🌱")
                        .font(.caption)
                        .foregroundColor(.gray)
                        .transition(.opacity)
                }
            }
            .padding()
            .hoverEffect(.lift)
            
            // ✅ Task Completion Button
            Button(action: {
                completeTask()
            }) {
                Text(isCompleted ? "✅ Completed!" : "Mark as Done")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .background(isCompleted ? Color.gray : Color.green)
                    .cornerRadius(10)
            }
            .disabled(isCompleted)
            
            // 🔄 Refresh Task Button
            Button(action: {
                dailyDeed = deeds.randomElement() ?? "Spread kindness!"
                isCompleted = false
            }) {
                Text("🔄 Refresh Task")
                    .font(.subheadline)
                    .foregroundColor(.blue)
            }
            .padding()
            
            Spacer()
        }
        .padding()
        .onAppear(perform: startMotivationTimer)
        .alert(isPresented: $showBadgePopup) {
            Alert(
                title: Text("🎉 New Badge Unlocked!"),
                message: Text("You've earned a new badge! Check your Profile."),
                dismissButton: .default(Text("OK"))
            )
        }
        .alert(isPresented: $showBadgePopup) {
                Alert(
                    title: Text("🎉 New Badge Unlocked!"),
                    message: Text("You've earned a new badge! Check your Profile."),
                    dismissButton: .default(Text("OK"))
                )
            }
    }
    
    func completeTask() {
        guard !isCompleted else { return }
        
        isCompleted = true
        streak += 1
        tasksCompleted += 1
        updatePetGrowth()
        checkForBadgeUnlock()
    }
    
    func updatePetGrowth() {
        if petStage < maxPetStage - 1 {
            withAnimation {
                petStage += 1
            }
            if petStage % 2 == 0 {
                showProgressPopup = true
            }
        } else {
            evolvePet()
        }
    }
    
    func evolvePet() {
        var completedPetsArray = completedPets.split(separator: ",").map { String($0) }
        if !completedPetsArray.contains(petType) {
            completedPetsArray.append(petType)
        }
        completedPets = completedPetsArray.joined(separator: ",")
        
        petStage = 0
        if let nextBird = birdOptions.first(where: { !completedPetsArray.contains($0) }) {
            petType = nextBird
        } else {
            print("All birds completed!")
        }
    }
    
    func startMotivationTimer() {
        Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            DispatchQueue.main.async {
                showMotivationPopup = true
            }
        }
    }
    
    func playMotivationSound() {
        AudioServicesPlaySystemSound(1009)
    }
    
    func checkForBadgeUnlock() {
        // Check if tasksCompleted is divisible by 5 and if it's a new milestone
        if tasksCompleted % 5 == 0 && tasksCompleted > 0 {
            badgeCount += 1
            showBadgePopup = true
        }
    }

}
