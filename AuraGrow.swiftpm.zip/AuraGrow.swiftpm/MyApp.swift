import SwiftUI

@main
struct MyApp: App {
    @AppStorage("soundEnabled") private var soundEnabled: Bool = true
    @AppStorage("selectedMusic") private var selectedMusic: String = "Relaxing"

    var body: some Scene {
        WindowGroup {
            ContentView()  // ✅ Loads the TabView with bottom navigation
                .onAppear {
                    if soundEnabled {
                        Task { @MainActor in
                            BackgroundMusicManager.shared.setMusic(trackName: selectedMusic)
                        }
                    }
                }
        }
    }
}
