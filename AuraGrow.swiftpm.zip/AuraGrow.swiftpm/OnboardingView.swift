import SwiftUI

struct OnboardingView: View {
    @AppStorage("hasCompletedOnboarding") private var hasCompletedOnboarding: Bool = false
    @AppStorage("username") private var username: String = "User"
    @AppStorage("petName") private var petName: String = ""

    @State private var tempPetName: String = ""
    @State private var showHomeScreen = false
    @State private var showConfetti = false

    var body: some View {
        ZStack {
            // Background Gradient
            LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.8), Color.cyan.opacity(0.9)]),
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing)
                .ignoresSafeArea()

            VStack {
                Spacer()

                if showHomeScreen {
                    HomeView()
                        .transition(AnyTransition.opacity.combined(with: .move(edge: .bottom)))
                        .zIndex(1) // Ensure HomeView is on top during transition
                } else {
                    VStack(spacing: 20) {
                        if hasCompletedOnboarding {
                            VStack {
                                Text("Welcome back, Let's help out \(username)!")
                                    .font(.largeTitle)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.black.opacity(0.3))
                                    .cornerRadius(10)
                                    .transition(.opacity)
                                    .animation(.easeIn(duration: 1), value: hasCompletedOnboarding)

                                Text("Your bird is waiting for you! 🐦")
                                    .font(.title2)
                                    .foregroundColor(.white.opacity(0.8))
                                    .transition(.opacity)
                                    .animation(.easeIn(duration: 1), value: hasCompletedOnboarding)
                            }
                            .padding()
                            .background(Color.black.opacity(0.2))
                            .cornerRadius(15)
                            .shadow(radius: 10)
                            .transition(.opacity)
                            .onAppear {
                                DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                                    withAnimation {
                                        showHomeScreen = true
                                    }
                                }
                            }
                        } else {
                            VStack {
                                Text("Welcome, \(username)! ")
                                    .font(.largeTitle)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding()
                                    
                                    .cornerRadius(10)

                                Text("Give a name for your buddy:")
                                    .font(.title2)
                                    .fontWeight(.medium)
                                    .foregroundColor(.white.opacity(0.9))
                                

                                TextField("Enter bird's name", text: $tempPetName)
                                    .textFieldStyle(RoundedBorderTextFieldStyle())
                                    .padding()
                                    .background(Color.white.opacity(0.3))
                                    .cornerRadius(10)
                                    .foregroundColor(.black)
                                    .multilineTextAlignment(.center)
                            }
                            .padding()
                            .background(Color.black.opacity(0.2))
                            .cornerRadius(15)
                            .shadow(radius: 10)

                            Button(action: completeOnboarding) {
                                Text("Let's Fly!")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .padding()
                                    .background(Color.blue)
                                    .cornerRadius(10)
                                    .transition(.scale)
                                    .animation(.spring(), value: hasCompletedOnboarding)
                            }
                            .padding(.top, 10)
                        }
                    }
                    .padding()
                }

                Spacer()
            }

            // Confetti Effect
            if showConfetti {
                ConfettiView()
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut, value: hasCompletedOnboarding)
    }

    // Complete Onboarding & Show Confetti
    private func completeOnboarding() {
        guard !tempPetName.isEmpty else { return }
        
        petName = tempPetName
        hasCompletedOnboarding = true
        showConfetti = true
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            withAnimation {
                showHomeScreen = true
            }
            showConfetti = false
        }
    }
}

import SwiftUI

struct ConfettiView: View {
    @State private var particles: [ConfettiParticle] = []

    var body: some View {
        ZStack {
            ForEach(particles) { particle in
                Circle()
                    .fill(particle.color)
                    .frame(width: particle.size, height: particle.size)
                    .position(particle.position)
                    .opacity(particle.opacity)
            }
        }
        .onAppear {
            generateConfetti()
        }
    }

    private func generateConfetti() {
        particles.removeAll()
        
        for _ in 1...50 {
            let particle = ConfettiParticle(
                id: UUID(),
                position: CGPoint(x: CGFloat.random(in: 0...UIScreen.main.bounds.width),
                                  y: CGFloat.random(in: 0...UIScreen.main.bounds.height / 2)),
                size: CGFloat.random(in: 5...18),
                opacity: Double.random(in: 0.6...1),
                color: [Color.yellow, Color.green, Color.blue, Color.white].randomElement()!
            )
            particles.append(particle)
        }

        withAnimation(.easeOut(duration: 3)) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                particles = []
            }
        }
    }
}

// 🎊 Confetti Particle Model
struct ConfettiParticle: Identifiable {
    let id: UUID
    var position: CGPoint
    var size: CGFloat
    var opacity: Double
    var color: Color
}

// 🔍 Preview
#Preview {
    OnboardingView()
}
