import SwiftUI
import PhotosUI

struct ProfileView: View {
    @AppStorage("username") private var username: String = "User"
    @AppStorage("petName") private var petName: String = "Fluffy"
    @AppStorage("petType") private var petType: String = "Parrot"
    @AppStorage("petStage") private var petStage: Int = 0
    @AppStorage("completedPets") private var completedPets: String = ""
    @AppStorage("tasksCompleted") private var tasksCompleted: Int = 0
    @AppStorage("badgeCount") private var badgeCount: Int = 0
    @AppStorage("unlockedBadges") private var unlockedBadges: String = "" // Store unlocked badge indices

    @State private var badgeScale: CGFloat = 1.0
    @State private var selectedImage: UIImage? = nil
    @State private var isImagePickerPresented = false
    @State private var animatedBadges: Set<Int> = []

    let birdOptions = ["Parrot", "Canary", "Sparrow", "Owl", "Pigeon", "Peacock"]
    let maxPetStage = 5

    var currentBirdImage: String {
        return "\(petType.lowercased())\(min(petStage + 1, maxPetStage))"
    }

    // Unlock badge every 5 tasks completed
    func checkAndUnlockBadge() {
        let newBadgeCount = tasksCompleted / 5
        if newBadgeCount > badgeCount {
            badgeCount = newBadgeCount
            unlockedBadges = Array(0..<badgeCount).map { "\($0)" }.joined(separator: ", ")
        }
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Profile Picture
                VStack {
                    if let image = selectedImage {
                        Image(uiImage: image)
                            .resizable()
                            .clipShape(Circle())
                            .frame(width: 120, height: 120)
                            .overlay(Circle().stroke(Color.blue, lineWidth: 3))
                    } else {
                        Image(systemName: "person.crop.circle")
                            .resizable()
                            .frame(width: 120, height: 120)
                            .foregroundColor(.gray)
                    }
                }
                .onTapGesture {
                    isImagePickerPresented = true
                }
                .sheet(isPresented: $isImagePickerPresented) {
                    ImagePicker(selectedImage: $selectedImage)
                }

                // User Name
                TextField("Enter Name", text: $username)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal)

                // Pet Name
                TextField("Enter Pet Name", text: $petName)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(10)
                    .padding(.horizontal)

                // Bird Selection
                Picker("Choose Your Bird", selection: $petType) {
                    ForEach(birdOptions, id: \.self) { bird in
                        Text(bird)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding()

                // Current Bird Image
                Image(currentBirdImage)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 150)
                    .padding(.top, 30)

                // 🏅 Achievements Section
                VStack {
                    Text("🏅 Achievements")
                        .font(.headline)
                        .padding(.top)
                    
                    Text("Tasks Completed: \(tasksCompleted)")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    Spacer()
                    Spacer()
                    LazyVGrid(columns: [GridItem(.flexible(), spacing: 15), GridItem(.flexible(), spacing: 15)], spacing: 15) {
                        ForEach(0..<badgeCount, id: \.self) { index in
                            Image("badge_\(index + 1)")
                                .resizable()
                                .frame(width: 120, height: 120)
                                .scaledToFit()
                                .clipShape(Circle())  // Making the badge rounded
                                .overlay(Circle().stroke(Color.blue, lineWidth: 4))  // Optional border
                                .scaleEffect(animatedBadges.contains(index) ? 1.5 : 1.0)
                                .onAppear {
                                    if !animatedBadges.contains(index) {
                                        animatedBadges.insert(index)
                                        // Adding the animation effect
                                        withAnimation(.easeIn(duration: 0.5)) {
                                            badgeScale = 1.5
                                        }
                                        // Delaying the reverse animation to remove scaling
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                            withAnimation(.easeOut(duration: 0.5)) {
                                                badgeScale = 1.0
                                            }
                                            // Removing from animatedBadges after animation
                                            animatedBadges.remove(index)
                                        }
                                    }
                                }
                        }
                    }
                    .padding(.top, 10)
                    .padding()
                }

                Spacer()
            }
            .padding()
            .onAppear {
                tasksCompleted = UserDefaults.standard.integer(forKey: "tasksCompleted")
                checkAndUnlockBadge() // Check if a badge should be unlocked when the view appears
            }
        }
    }
}



struct ImagePicker: UIViewControllerRepresentable {
    @Binding var selectedImage: UIImage?

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = .photoLibrary
        return picker
    }

    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}

    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: ImagePicker

        init(_ parent: ImagePicker) {
            self.parent = parent
        }

        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
            if let image = info[.originalImage] as? UIImage {
                parent.selectedImage = image
            }
            picker.dismiss(animated: true)
        }
    }
}

#Preview {
    ProfileView()
}
