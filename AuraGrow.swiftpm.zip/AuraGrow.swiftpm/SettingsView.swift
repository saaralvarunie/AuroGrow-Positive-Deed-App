import SwiftUI
import UserNotifications
import AVFoundation

struct SettingsView: View {
    @AppStorage("theme") private var theme: String = "System"
    @AppStorage("dailyReminder") private var dailyReminder: Bool = true
    @AppStorage("soundEnabled") private var soundEnabled: Bool = true
    @AppStorage("selectedMusic") private var selectedMusic: String = "None"

    @State private var showAboutUs: Bool = false
    @State private var showResetAlert: Bool = false

    private let musicTracks = ["None", "Relaxing", "Happy", "Focus"]

    var body: some View {
        NavigationStack {
            Form {
                // 🎨 Appearance Section
                Section(header: Label("Appearance", systemImage: "paintbrush").foregroundColor(.blue)) {
                    Picker("App Theme", selection: $theme) {
                        Label("System Default", systemImage: "gear").tag("System")
                        Label("Light Mode", systemImage: "sun.max.fill").tag("Light")
                        Label("Dark Mode", systemImage: "moon.fill").tag("Dark")
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .onChange(of: theme) { _ in applyTheme() }
                }

                // 🎵 Sound & Background Music
                Section(header: Label("Sound & Music", systemImage: "music.note").foregroundColor(.purple)) {
                    Toggle("Enable Sound & Music", isOn: $soundEnabled)
                        .onChange(of: soundEnabled) { _ in handleMusicPlayback() }

                    Picker("Background Music", selection: $selectedMusic) {
                        ForEach(musicTracks, id: \.self) { track in
                            Text(track)
                        }
                    }
                    .pickerStyle(MenuPickerStyle())
                    .onChange(of: selectedMusic) { newTrack in
                        BackgroundMusicManager.shared.setMusic(trackName: soundEnabled ? newTrack : "None")
                    }
                }


                // ℹ️ About Us
                Section {
                    Button(action: { showAboutUs.toggle() }) {
                        Label("About Us", systemImage: "info.circle")
                    }
                }

                // 🔄 Reset Progress
                Section {
                    Button(action: { showResetAlert = true }) {
                        Label("Reset Progress", systemImage: "arrow.clockwise")
                            .foregroundColor(.red)
                    }
                }
            }
            .navigationTitle("⚙️ Settings")
            .sheet(isPresented: $showAboutUs) {
                AboutUsView()
            }
            .alert(isPresented: $showResetAlert) {
                Alert(
                    title: Text("Reset Progress"),
                    message: Text("Are you sure? This will erase all progress!"),
                    primaryButton: .destructive(Text("Reset")) {
                        resetProgress()
                    },
                    secondaryButton: .cancel()
                )
            }
        }
    }

    // 🛑 Reset Progress Function
    // 🛑 Reset Progress Function
    func resetProgress() {
        // Reset general progress
        UserDefaults.standard.set(0, forKey: "streak")
        UserDefaults.standard.set(0, forKey: "petStage")
        UserDefaults.standard.set("Parrot", forKey: "petType")
        UserDefaults.standard.set(0, forKey: "tasksCompleted")
        UserDefaults.standard.set("", forKey: "completedPets")

        // Reset badge count
        UserDefaults.standard.set(0, forKey: "badgeCount") // Assuming you are storing badge count here

        // Notify ProfileView & HomeView to update
        NotificationCenter.default.post(name: NSNotification.Name("ResetProgress"), object: nil)
    }


    // 🌓 Apply Theme Change
    func applyTheme() {
        let style: UIUserInterfaceStyle = {
            switch theme {
            case "Light": return .light
            case "Dark": return .dark
            default: return .unspecified
            }
        }()
        UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .forEach { $0.overrideUserInterfaceStyle = style }
    }

    // 🔔 Request Notification Permission
    func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, _ in
            if granted { scheduleDailyReminder() }
        }
    }

    // 📅 Schedule a Daily Reminder
    func scheduleDailyReminder() {
        let content = UNMutableNotificationContent()
        content.title = "Daily Good Deed!"
        content.body = "Don't forget to complete your daily good deed and help your pet grow! 🐾"
        content.sound = .default

        var dateComponents = DateComponents()
        dateComponents.hour = 9
        dateComponents.minute = 0

        let trigger = UNCalendarNotificationTrigger(dateMatching: dateComponents, repeats: true)
        let request = UNNotificationRequest(identifier: "dailyReminder", content: content, trigger: trigger)

        UNUserNotificationCenter.current().add(request)
    }

    // 🎵 Handle Background Music Playback
    func handleMusicPlayback() {
        BackgroundMusicManager.shared.setMusic(trackName: soundEnabled ? selectedMusic : "None")
    }
}

// ℹ️ About Us Popup
struct AboutUsView: View {
    @Environment(\.dismiss) var dismiss
    var body: some View {
        VStack(spacing: 20) {
            Text("🌟 About Us")
                .font(.title)
                .fontWeight(.bold)

            Text("AuraGrow encourages positivity by completing daily good deeds. Grow your virtual pet as you spread kindness! 💖")
                .font(.body)
                .multilineTextAlignment(.center)
                .padding()

            Button("Close") {
                dismiss()
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(10)
        }
        .padding()
    }
}

// 🔍 Preview
#Preview {
    SettingsView()
}
